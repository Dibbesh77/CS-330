///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}

	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	// destroy the textures loaded into OpenGL memory
	DestroyGLTextures();

	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots. There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
		m_textureIDs[i].ID = -1;
	}

	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method loads and binds the textures used in the scene.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// load the fabric texture for the lamp shade and table surface
	CreateGLTexture("textures/fabric.jpg", "fabric");

	// load the metal texture for the lamp base and pole
	CreateGLTexture("textures/metal.jpg", "metal");

	// load the notebook texture for the decorative book
	CreateGLTexture("textures/Notebook.jpg", "notebook");

	// bind the loaded textures to OpenGL texture slots
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method defines the material properties used by the
 *  Phong lighting model for the objects in the scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// reflective material for the textured table plane
	OBJECT_MATERIAL tableMaterial;
	tableMaterial.diffuseColor = glm::vec3(0.75f, 0.75f, 0.75f);
	tableMaterial.specularColor = glm::vec3(0.35f, 0.35f, 0.35f);
	tableMaterial.shininess = 24.0f;
	tableMaterial.tag = "tableMaterial";
	m_objectMaterials.push_back(tableMaterial);

	// shiny material for the lamp's metal components
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.diffuseColor = glm::vec3(0.70f, 0.70f, 0.75f);
	metalMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	metalMaterial.shininess = 64.0f;
	metalMaterial.tag = "metalMaterial";
	m_objectMaterials.push_back(metalMaterial);

	// soft material for the fabric lamp shade
	OBJECT_MATERIAL fabricMaterial;
	fabricMaterial.diffuseColor = glm::vec3(0.80f, 0.80f, 0.80f);
	fabricMaterial.specularColor = glm::vec3(0.20f, 0.20f, 0.20f);
	fabricMaterial.shininess = 8.0f;
	fabricMaterial.tag = "fabricMaterial";
	m_objectMaterials.push_back(fabricMaterial);

	// moderately reflective material for the notebook
	OBJECT_MATERIAL notebookMaterial;
	notebookMaterial.diffuseColor = glm::vec3(0.80f, 0.80f, 0.80f);
	notebookMaterial.specularColor = glm::vec3(0.35f, 0.35f, 0.35f);
	notebookMaterial.shininess = 20.0f;
	notebookMaterial.tag = "notebookMaterial";
	m_objectMaterials.push_back(notebookMaterial);

	// bright material for the visible light bulb
	OBJECT_MATERIAL bulbMaterial;
	bulbMaterial.diffuseColor = glm::vec3(1.0f, 0.95f, 0.70f);
	bulbMaterial.specularColor = glm::vec3(1.0f, 1.0f, 0.90f);
	bulbMaterial.shininess = 48.0f;
	bulbMaterial.tag = "bulbMaterial";
	m_objectMaterials.push_back(bulbMaterial);

	// dark material for the pull switch and handle
	OBJECT_MATERIAL darkMaterial;
	darkMaterial.diffuseColor = glm::vec3(0.15f, 0.15f, 0.15f);
	darkMaterial.specularColor = glm::vec3(0.25f, 0.25f, 0.25f);
	darkMaterial.shininess = 12.0f;
	darkMaterial.tag = "darkMaterial";
	m_objectMaterials.push_back(darkMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method configures two point lights so that the lamp,
 *  notebook, and table surface remain clearly visible.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// enable custom Phong lighting in the fragment shader
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// warm point light positioned near the lamp bulb
	m_pShaderManager->setVec3Value(
		"pointLights[0].position",
		0.0f, 5.0f, 1.0f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].ambient",
		0.20f, 0.16f, 0.10f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].diffuse",
		1.0f, 0.82f, 0.55f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].specular",
		1.0f, 0.90f, 0.70f);

	m_pShaderManager->setBoolValue(
		"pointLights[0].bActive",
		true);

	// cool secondary light fills shadows across the scene
	m_pShaderManager->setVec3Value(
		"pointLights[1].position",
		-6.0f, 7.0f, 5.0f);

	m_pShaderManager->setVec3Value(
		"pointLights[1].ambient",
		0.08f, 0.10f, 0.16f);

	m_pShaderManager->setVec3Value(
		"pointLights[1].diffuse",
		0.35f, 0.45f, 0.70f);

	m_pShaderManager->setVec3Value(
		"pointLights[1].specular",
		0.45f, 0.55f, 0.85f);

	m_pShaderManager->setBoolValue(
		"pointLights[1].bActive",
		true);

	// keep all unused lights disabled
	m_pShaderManager->setBoolValue("pointLights[2].bActive", false);
	m_pShaderManager->setBoolValue("pointLights[3].bActive", false);
	m_pShaderManager->setBoolValue("pointLights[4].bActive", false);
	m_pShaderManager->setBoolValue("directionalLight.bActive", false);
	m_pShaderManager->setBoolValue("spotLight.bActive", false);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures, materials, and lights in memory.
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load the textures used in the scene
	LoadSceneTextures();

	// define the material properties used by the objects
	DefineObjectMaterials();

	// configure the light sources used by the scene
	SetupSceneLights();

	// Only one instance of each mesh needs to be loaded into memory.
	// These shapes are used to construct a desk lamp scene.
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes.
 ***********************************************************/
void SceneManager::RenderScene()
{
	// Declare the variables for the transformations.
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/******************************************************************/
	// Ground/table surface
	/******************************************************************/
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply a texture and reflective material to the plane
	SetShaderTexture("fabric");
	SetTextureUVScale(8.0f, 5.0f);
	SetShaderMaterial("tableMaterial");

	m_basicMeshes->DrawPlaneMesh();

	/******************************************************************/
	// Lamp base - wide cylinder sitting on the table
	/******************************************************************/
	scaleXYZ = glm::vec3(2.4f, 0.35f, 2.4f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 0.18f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply the metal texture and reflective metal material
	SetShaderTexture("metal");
	SetTextureUVScale(2.0f, 1.0f);
	SetShaderMaterial("metalMaterial");

	m_basicMeshes->DrawCylinderMesh();

	/******************************************************************/
	// Lamp pole - tall thin cylinder rising from the base
	/******************************************************************/
	scaleXYZ = glm::vec3(0.28f, 4.0f, 0.28f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 2.25f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply the metal texture and reflective metal material
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 3.0f);
	SetShaderMaterial("metalMaterial");

	m_basicMeshes->DrawCylinderMesh();

	/******************************************************************/
	// Lamp shade - box scaled wider than tall
	/******************************************************************/
	scaleXYZ = glm::vec3(3.8f, 1.4f, 3.8f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 45.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 4.65f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply the fabric texture and soft fabric material
	SetShaderTexture("fabric");
	SetTextureUVScale(4.0f, 2.0f);
	SetShaderMaterial("fabricMaterial");

	m_basicMeshes->DrawBoxMesh();

	/******************************************************************/
	// Light bulb - small sphere inside the lamp shade
	/******************************************************************/
	scaleXYZ = glm::vec3(0.65f, 0.65f, 0.65f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 4.15f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 0.95f, 0.65f, 1.0f);
	SetShaderMaterial("bulbMaterial");

	m_basicMeshes->DrawSphereMesh();

	/******************************************************************/
	// Small pull switch - thin hanging cylinder
	/******************************************************************/
	scaleXYZ = glm::vec3(0.08f, 1.25f, 0.08f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(1.25f, 3.45f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.08f, 0.08f, 0.08f, 1.0f);
	SetShaderMaterial("darkMaterial");

	m_basicMeshes->DrawCylinderMesh();

	/******************************************************************/
	// Pull switch handle - small box at the bottom of the cord
	/******************************************************************/
	scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 45.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(1.25f, 2.75f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.10f, 0.10f, 0.10f, 1.0f);
	SetShaderMaterial("darkMaterial");

	m_basicMeshes->DrawBoxMesh();

	/******************************************************************/
	// Decorative book/notebook beside the lamp
	/******************************************************************/
	scaleXYZ = glm::vec3(3.0f, 0.25f, 2.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = -18.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-4.2f, 0.15f, 1.2f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply the notebook texture and notebook material
	SetShaderTexture("notebook");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("notebookMaterial");

	m_basicMeshes->DrawBoxMesh();
}